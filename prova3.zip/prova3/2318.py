matriz = []

for l in range(0, 3):
	for c in range(0, 3):
		linha = list(map(int, input().split()))
		matriz.append(linha)

linhaOriginal = 0
